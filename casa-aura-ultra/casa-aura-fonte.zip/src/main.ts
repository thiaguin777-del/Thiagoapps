// ============================================================
// Casa Aura Ultra — ponto de entrada
// ------------------------------------------------------------
// Só orquestra. Nada de lógica de cena aqui: a ordem é
//   estilo -> máquina de estados -> cena -> UI -> service worker
// e cada um desses vive no seu módulo.
// ============================================================
import './ui/estilo.css';
import './ui/ultra.css';
import { fsm } from './core/StateMachine';
import { registrarServiceWorker } from './core/ServiceWorker';
import { qualidade } from './core/QualityController';
import { analytics } from './core/Analytics';

/**
 * Marcos do boot. Não é depuração descartável: o ambiente de
 * desenvolvimento não tem GPU, então quando algo trava no aparelho do
 * cliente esta lista é a única forma de saber ONDE travou. Fica.
 */
const marcos: { etapa: string; ms: number }[] = [];
function marco(etapa: string): void {
  marcos.push({ etapa, ms: Math.round(performance.now()) });
  (window as unknown as { __auraMarcos?: unknown }).__auraMarcos = marcos;
}

/**
 * Vigia o fallback do legado. `init()` NÃO lança na maioria das falhas —
 * ela chama `showFallback` internamente e retorna normalmente (sem
 * contexto WebGL, falha ao construir a cena, e o timeout de 20 s que
 * dispara muito depois de `init()` ter voltado). Um try/catch em volta do
 * `init()` pega só o caso mais raro.
 *
 * Então o gatilho é o efeito observável comum a TODOS os caminhos: a
 * classe `.show` aparecendo em `#fallback`. Assim o fallback rico entra
 * inclusive quando a falha acontece minutos depois do boot.
 */
function vigiarFallback(): void {
  const el = document.getElementById('fallback');
  if (!el) return;
  const entrar = async () => {
    // A trava vem ANTES de montar: a partir daqui nenhuma transição da
    // máquina de estados é válida, e o resto do boot não vai tentar
    // levantar hero, hotspots e apresentação por baixo do véu.
    fsm.travar('fallback do legado ativado');
    const { montarFallback } = await import('./ui/Fallback');
    montarFallback('fallback do legado ativado');
  };
  if (el.classList.contains('show')) { void entrar(); return; }
  const obs = new MutationObserver(() => {
    if (el.classList.contains('show')) { obs.disconnect(); void entrar(); }
  });
  obs.observe(el, { attributes: true, attributeFilter: ['class'] });
}

/**
 * Entra no PRESENTATION_SAFE. Separado de `principal()` porque também
 * pode ser chamado muito depois do boot — o aparelho pode aguentar os
 * primeiros minutos e desabar quando a apresentação entra num plano
 * interno com vidro e volumetria.
 */
async function entrarNoModoSeguro(motivo: string, maquina: typeof fsm): Promise<void> {
  const { montarModoSeguro, modoSeguroAtivo } = await import('./ui/ModoSeguro');
  if (modoSeguroAtivo()) return;
  analytics.registrar('modo_seguro', { motivo });
  montarModoSeguro({
    motivo,
    abrirComercial: () => {
      // A jornada comercial é a mesma: o painel de planos é o do 3D.
      const painel = document.getElementById('commercial');
      void maquina.ir('COMMERCIAL', () => {
        painel?.classList.add('visible');
        painel?.scrollIntoView({ behavior: 'auto' });
      });
    },
  });
}

/**
 * O relatório que a diretriz de fechamento pede, em `?debug=1`: tier,
 * percentis de FPS e de tempo de quadro, draw calls, triângulos, DPR,
 * string do renderizador e o motivo da última troca de tier.
 *
 * Fica no console e num painel, e também em `window.__auraProtecao` para
 * quem quiser ler de fora. Nada aqui é promessa: são leituras do
 * aparelho de quem abriu.
 */
function ligarRelatorioDeDebug(p: { relatorio: () => Record<string, unknown> }): void {
  if (!new URLSearchParams(location.search).has('debug')) return;
  const el = document.createElement('pre');
  el.id = 'relatorio-protecao';
  el.style.cssText = 'position:fixed;right:8px;bottom:8px;z-index:400;margin:0;'
    + 'padding:10px 12px;background:rgba(5,7,10,.86);color:#cfe;font:11px/1.45 ui-monospace,monospace;'
    + 'border-radius:8px;max-width:46vw;white-space:pre-wrap;pointer-events:none';
  document.body.appendChild(el);
  window.setInterval(() => {
    const r = p.relatorio();
    el.textContent = Object.entries(r)
      .map(([k, v]) => `${k.padEnd(14)} ${typeof v === 'object' ? JSON.stringify(v) : String(v)}`)
      .join('\n');
  }, 1000);
}

/**
 * Anuncia uma mudança de estado para leitor de tela.
 *
 * Sem isto a experiência é silenciosa para quem não vê a tela mudar:
 * trocar de capítulo, entrar em apresentação ou cair no modo seguro não
 * produziam nenhum sinal audível. `role="status"` com `aria-live=polite`
 * interrompe a leitura em curso o mínimo possível.
 */
/** O que o leitor de tela ouve em cada estado. */
const NOME_DO_ESTADO: Record<string, string> = {
  HERO: 'Tela inicial da Casa Aura.',
  EXPLORING: 'Exploração livre. Use o mouse ou o toque para girar a casa.',
  CINEMATIC: 'Modo cinemático em reprodução.',
  PRESENTATION: 'Apresentação guiada em reprodução.',
  COMMERCIAL: 'Planos e valores.',
  FALLBACK: 'Visualização 3D indisponível. Planta e ficha técnica na tela.',
};

function anunciar(texto: string): void {
  const el = document.getElementById('anuncio');
  if (!el) return;
  // Texto idêntico ao anterior não é reanunciado por alguns leitores.
  // O espaço de largura zero força a mudança sem alterar o que se ouve.
  el.textContent = el.textContent === texto ? texto + '\u200b' : texto;
}

/**
 * `Escape` fecha o que estiver aberto, em qualquer modo.
 *
 * O legado já tratava `Escape` para sair da apresentação. O painel
 * comercial não fechava com tecla nenhuma — e ele cobre a tela inteira,
 * então quem chegou ali de teclado ficava preso.
 */
function ligarEscapeGlobal(maquina: typeof fsm): void {
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    const painel = document.getElementById('commercial');
    if (painel?.classList.contains('visible')) {
      painel.classList.remove('visible');
      anunciar('Planos fechados.');
      if (!maquina.emFallback) void maquina.ir('EXPLORING');
      e.preventDefault();
    }
  });
}

async function principal(): Promise<void> {
  document.body.dataset.estado = fsm.atual();   // LOADING
  marco('inicio');
  vigiarFallback();

  // A cena é carregada de forma assíncrona e SEPARADA do bundle inicial.
  // Regra de ouro nº 3: nada que não seja crítico para o primeiro quadro
  // entra no bundle de entrada. O three.js e a cena somam ~1 MB; o hero
  // aparece antes disso.
  const cena = await import('./legado/cena-bruta');
  marco('modulo-da-cena');

  try {
    await cena.init();
    marco('init');
  } catch (e) {
    console.error('Casa Aura: falha fatal na inicialização', e);
    // O fallback do legado é uma mensagem de desculpas. O rico entra por
    // cima com planta, ficha e contato — conteúdo que ainda vende a casa
    // num aparelho que não roda WebGL.
    // O observador acima monta o fallback rico quando esta chamada marcar
    // `#fallback` com `.show`.
    cena.showFallback('init-exception', e);
    return;
  }

  // `init()` pode ter caído no fallback sem lançar. Se a cena não subiu,
  // não há o que decorar com cáusticas e feixes.
  if (!cena._cenaPronta()) {
    console.warn('Casa Aura: cena não subiu, seguindo só com o fallback');
    return;
  }

  // ------------------------------------------------------------
  // UPGRADES DA CENA
  // Cáusticas, feixes volumétricos, partículas, DOF, anti-aliasing e o
  // diretor de câmera entram AQUI, depois do init: antes dele os
  // materiais e o composer ainda não existem. É também por isso que o
  // módulo é importado de forma estática mas só executa agora — ele não
  // toca em nada no momento do import.
  // ------------------------------------------------------------
  const { cenaAura } = await import('./scenes/CasaAuraScene');
  marco('modulo-de-upgrades');
  try {
    cenaAura.montar({
      scene: cena.scene, camera: cena.camera, renderer: cena.renderer,
      controls: cena.controls, composer: cena.composer,
      M: cena.M, Quality: cena.Quality, houseGroup: cena.houseGroup,
      lampLights: cena.lampLights,
      sunLight: cena.sunLight, solarTime: cena.solarTime,
      transitionNeedsCut: cena.transitionNeedsCut,
      doFadeCut: cena.doFadeCut,
      pointInEnvelope: cena.pointInEnvelope,
    });
  } catch (e) {
    // Um efeito que falha não pode derrubar a visita. A casa vale mais
    // que as cáusticas.
    console.error('Casa Aura: upgrades de cena falharam, seguindo sem eles', e);
  }

  // Expõe a cena para inspeção. Não é enfeite: o ambiente de
  // desenvolvimento não tem GPU, então quem mede de verdade é o Thiago no
  // iPad e no celular, e para isso ele precisa de um ponto de entrada.
  (window as unknown as { __auraCena?: unknown }).__auraCena = cena;

  const w2 = window as unknown as { __auraAntesDoQuadro?: ((dt: number) => void)[] };
  w2.__auraAntesDoQuadro = w2.__auraAntesDoQuadro || [];
  w2.__auraAntesDoQuadro.push((dt) => cenaAura.quadro(dt, cena.solarTime));

  fsm.aoMudar((estado) => cenaAura.aoMudarEstado(estado));
  window.addEventListener('resize', () => {
    cenaAura.redimensionar(window.innerWidth, window.innerHeight);
  });

  // ------------------------------------------------------------
  // PRÉ-COMPILAÇÃO DE SHADER — contra o engasgo, não contra o FPS médio
  //
  // No Three.js o programa de um material só é compilado quando aquele
  // material aparece pela PRIMEIRA vez num quadro. O projeto não tinha
  // nenhuma pré-compilação: cada material novo que entrava em quadro
  // parava a thread principal enquanto o driver compilava, e isso
  // acontece exatamente quando a câmera começa a girar — ou seja, no
  // primeiro movimento do Modo Apresentação, com o corretor olhando.
  //
  // Isso não aparece em média de FPS nenhuma. Aparece como travadinha, e
  // travadinha é o defeito que o cliente relatou.
  //
  // POR QUE NÃO `compileAsync` COM CORRIDA CONTRA UM RELÓGIO
  // Foi a primeira tentativa, e ela MEDIDAMENTE não funciona:
  // `compileAsync` chama `compile()` de forma SÍNCRONA e só depois
  // devolve uma Promise que espera o driver reportar "pronto". Sem a
  // extensão KHR_parallel_shader_compile o trabalho todo acontece
  // dentro da chamada, com a thread travada — e um `Promise.race`
  // contra `setTimeout` nunca chega a ser avaliado. Medido aqui:
  // 58 -> 99 programas em 37,6 s, com um teto declarado de 9 s. O teto
  // era decorativo.
  //
  // Em vez disso, a compilação vai em PEDAÇOS. `renderer.compile` aceita
  // uma cena de objetos e uma cena-alvo separada de onde tirar luzes,
  // ambiente e névoa — então dá para compilar um punhado de objetos por
  // vez, com as luzes certas, cedendo um quadro entre os pedaços. O
  // orçamento passa a ser real: quando estoura, o que faltou compila no
  // caminho, como antes. Nunca fica pior que o estado anterior, e a tela
  // de carregamento continua animando.
  //
  // A ordem é do mais perto da câmera inicial para o mais longe: se o
  // orçamento estourar, o que sobrou de fora é o que aparece por último.
  // ------------------------------------------------------------
  try {
    const r = cena.renderer as unknown as {
      info: { programs?: unknown[] };
      compile: (s: unknown, c: unknown, alvo?: unknown) => unknown;
    };
    const t0 = performance.now();
    const antes = r.info.programs?.length ?? 0;

    // Tipo estrutural em vez de importar `three` aqui: main.ts é o
    // ponto de entrada e não precisa da biblioteca inteira no escopo
    // para percorrer um grafo.
    type Obj = {
      material?: unknown;
      getWorldPosition: (v: { distanceToSquared: (o: unknown) => number }) => unknown;
    };
    const comMaterial: Obj[] = [];
    cena.scene.traverse((o: unknown) => {
      if ((o as Obj).material) comMaterial.push(o as Obj);
    });
    const olho: unknown = cena.camera.position;
    const centro = cena.camera.position.clone() as {
      distanceToSquared: (o: unknown) => number;
    };
    comMaterial.sort((a, b) => {
      a.getWorldPosition(centro);
      const da = centro.distanceToSquared(olho);
      b.getWorldPosition(centro);
      return da - centro.distanceToSquared(olho);
    });

    const ORCAMENTO_MS = 6000;
    const PEDACO = 8;
    let compilados = 0;
    for (let i = 0; i < comMaterial.length; i += PEDACO) {
      if (performance.now() - t0 > ORCAMENTO_MS) break;
      const pedaco = comMaterial.slice(i, i + PEDACO);
      // Objeto com cara de cena: `compile` só chama `traverse` e
      // `traverseVisible` nele. Evita reparentar nada — mexer no grafo
      // real para compilar seria trocar um risco por outro.
      const falsaCena = {
        traverse: (fn: (o: Obj) => void) => { for (const o of pedaco) fn(o); },
        traverseVisible: (fn: (o: Obj) => void) => { for (const o of pedaco) fn(o); },
      };
      r.compile(falsaCena, cena.camera, cena.scene);
      compilados += pedaco.length;
      // ------------------------------------------------------------
      // CEDER O QUADRO SEM DEPENDER DE `requestAnimationFrame`
      //
      // rAF NÃO DISPARA em aba oculta. A primeira versão cedia só por
      // rAF, dentro do caminho de boot e ANTES de `fsm.ir('HERO')`: um
      // corretor que abre o link numa aba de fundo — o caso normal,
      // clicou e foi ler outra coisa — ficava preso na tela de
      // carregamento até voltar para a aba. E o orçamento não salvava,
      // porque ele só é conferido no TOPO do laço, enquanto a execução
      // estava parada no await. O fallback de 20 s do legado também não
      // pega: `initDone` já é verdadeiro a esta altura.
      //
      // Corrida entre o quadro e um relógio: em aba visível vence o rAF
      // (cede de verdade, a animação de carregamento continua); em aba
      // oculta vence o timer e o laço segue até o orçamento acabar.
      // ------------------------------------------------------------
      await new Promise((res) => {
        let pronto = false;
        const uma = () => { if (!pronto) { pronto = true; res(null); } };
        requestAnimationFrame(uma);
        setTimeout(uma, 50);
      });
    }
    const ms = performance.now() - t0;
    const depois = r.info.programs?.length ?? 0;
    console.info(`[preaquecimento] ${antes} -> ${depois} programas | `
      + `${compilados}/${comMaterial.length} objetos | ${ms.toFixed(0)} ms`);
    (window as unknown as { __auraPreaquecimento?: unknown }).__auraPreaquecimento =
      { antes, depois, objetos: comMaterial.length, compilados, ms: +ms.toFixed(1) };
  } catch (e) {
    console.warn('Casa Aura: pré-compilação falhou, seguindo sem ela', e);
  }

  // A cena subiu: sai de LOADING. O hero já está no DOM desde o começo —
  // o fade só descobre o que já existe.
  marco('upgrades');
  await fsm.ir('HERO');
  marco('hero');

  // A entrada do texto só começa depois do fade: animar por baixo do véu
  // preto é gastar a animação onde ninguém a vê.
  const { animarHero, ligarBotoesMagneticos } = await import('./ui/Hero');
  animarHero();
  ligarBotoesMagneticos();

  // O painel comercial e o áudio são carregados sob demanda, nunca no
  // caminho do primeiro quadro.
  const { montarComercial } = await import('./ui/Commercial');
  montarComercial(fsm);

  // A apresentação assume o botão herdado e roda o roteiro pelo diretor
  // de câmera. Ao terminar, cai no painel comercial — que é o ponto do
  // filme: a última coisa que o cliente vê é o convite.
  const { apresentacao } = await import('./ui/Presentation');
  apresentacao.montar(fsm, cena);

  // ------------------------------------------------------------
  // VALIDAÇÃO GEOMÉTRICA DO ROTEIRO — `?validar=1`
  //
  // O cliente relatou que a apresentação podia mostrar paisagem em vez
  // da casa. As causas mecânicas foram corrigidas no CameraDirector, mas
  // "corrigi a mecânica" não é o mesmo que "os oito enquadramentos estão
  // certos". Isto mede, lançando raios contra a geometria que está na
  // cena: quanto do quadro é casa, se o centro do quadro encontra a
  // casa, se a câmera está dentro de algum sólido, e se partida e
  // chegada estão do mesmo lado da fachada.
  //
  // Fora da flag o módulo nem é baixado: `import()` dinâmico dentro do
  // `if`. Custo zero em produção.
  // ------------------------------------------------------------
  if (new URLSearchParams(location.search).get('validar') === '1') {
    try {
      const { validarPlanos, malhasDeEdificio, medirEnquadramento } =
        await import('./core/ValidadorDePlanos');
      const casa = cena.houseGroup ?? cena.scene;
      const laudos = validarPlanos(
        apresentacao.roteiro, casa, cena.camera, cena.pointInEnvelope!,
      );
      const w = window as unknown as {
        __auraValidacao?: unknown; __auraMedirEnquadramento?: unknown;
      };
      w.__auraValidacao = laudos;
      // A MESMA medida, sobre a câmera VIVA. É o que permite auditar a
      // apresentação rodando pelo botão de verdade — coordenadas num
      // arquivo provam o roteiro, não provam o modo.
      const malhas = malhasDeEdificio(casa, cena.pointInEnvelope!);
      // O diretor, para o teste de trajetória. Ver o comentário de
      // `CameraDirector.estado`: sem isto, validar o percurso de um plano
      // exigiria onze minutos de relógio por plano nesta máquina.
      const { diretor } = await import('./core/CameraDirector');
      (w as unknown as { __auraDiretor?: unknown }).__auraDiretor = diretor;
      w.__auraMedirEnquadramento = () => ({
        ...medirEnquadramento(cena.camera, malhas),
        malhasDeEdificio: malhas.length,
        pos: cena.camera.position.toArray().map((v: number) => +v.toFixed(2)),
        fov: +cena.camera.fov.toFixed(2),
      });
      const ruins = laudos.filter((l) => l.problemas.length > 0);
      console.info(`[validador] ${laudos.length} planos, ${ruins.length} com problema`);
      for (const l of ruins) console.warn(`[validador] ${l.indice} ${l.titulo}:`, l.problemas);
    } catch (e) {
      console.error('[validador] falhou', e);
    }
  }

  // `await` + try/catch, e não `iniciar()` solto, por dois motivos:
  //
  // 1. Disparar uma função async sem await transforma qualquer exceção
  //    dentro dela numa rejeição não tratada — sem linha vermelha no
  //    console e sem interromper nada.
  // 2. Sem o await, `pronto` era marcado ANTES de os marcadores
  //    existirem. Não quebrava o produto, mas mentia para a telemetria e
  //    para qualquer verificação automatizada, que via zero hotspots numa
  //    experiência que estava correta. Marco de "pronto" tem de
  //    significar pronto.
  // O painel do Modo Seção assume o botão herdado `#btn-reveal`.
  const { hud } = await import('./ui/HUD');
  hud.montar();
  hud.aoAlternar = (ativo, eixo) => analytics.registrar('corte', { ativo, eixo });

  const { HotspotManager } = await import('./ui/HotspotManager');
  try {
    await HotspotManager.iniciar();
    HotspotManager.aoAbrir = (titulo) => analytics.registrar('hotspot', { titulo });
  } catch (e) {
    console.error('Casa Aura: hotspots falharam', e);
  }

  // O auto-scaler so entra depois que a cena esta de pe: durante o boot
  // ainda ha compilacao de shader e upload de textura, e rebaixar por
  // causa disso puniria o aparelho errado.
  qualidade.ligar({
    renderer: cena.renderer,
    composer: cena.composer,
    aoModoLeve: (ligado) => {
      document.body.dataset.modoLeve = ligado ? '1' : '';
      // Partículas e feixes volumétricos saem junto. Sem esta linha o
      // Modo Leve prometia mais do que entregava.
      cenaAura.modoLeve(ligado);
    },
  });

  // Pendura o auto-scaler no laco de render do legado.
  const w = window as unknown as { __auraPorQuadro?: (() => void)[] };
  w.__auraPorQuadro = w.__auraPorQuadro || [];
  w.__auraPorQuadro.push(() => qualidade.quadro());

  // ------------------------------------------------------------
  // PROTEÇÃO DE APRESENTAÇÃO — o governador de três tiers
  //
  // Vem DEPOIS do auto-scaler e o supera em autoridade: o auto-scaler
  // resolve o aparelho que está quase dando conta; o governador decide
  // se vale a pena continuar tentando. Quando ele manda para
  // PRESENTATION_SAFE, o laço de render para e a jornada comercial
  // continua por outro meio.
  //
  // A sonda usa o contexto WebGL de VERDADE, já criado — não um
  // contexto de teste. Um contexto extra só para sondar consome um dos
  // poucos que o navegador concede, e num aparelho fraco isso é caro.
  // ------------------------------------------------------------
  const { protecao } = await import('./core/ProtecaoDeApresentacao');
  protecao.sondar(cena.contextoWebGL());
  protecao.aoTrocarTier = (tier, motivo) => {
    analytics.registrar('tier', { tier, motivo });
    if (tier === 'PRESENTATION_SAFE') void entrarNoModoSeguro(motivo, fsm);
  };
  const forcado = new URLSearchParams(location.search).get('tier');
  protecao.ligar({
    pixelRatio: (v) => cena.renderer.setPixelRatio(
      Math.max(0.4, Math.min(v, window.devicePixelRatio || 1))),
    sombras: (on) => cena.controlarSombras(on),
    posProcessamento: (on) => cena.controlarPosProcessamento(on),
    antialias: (on) => cena.controlarAntialias(on),
    decoracao: (on) => cenaAura.modoLeve(!on),
    transmissao: (on) => cena.controlarTransmissao(on),
    toneMappingSimples: (on) => cena.controlarToneMappingSimples(on),
    estatisticas: () => cena.estatisticasDoQuadro(),
    renderizar: (on) => (on ? cena.resumeRenderLoop() : cena.pauseRenderLoop()),
  }, forcado === 'REALTIME' || forcado === 'COMPATIBILITY'
     || forcado === 'PRESENTATION_SAFE' ? forcado : undefined);
  w.__auraPorQuadro.push(() => protecao.quadro());
  (window as unknown as { __auraProtecao?: unknown }).__auraProtecao = protecao;

  // ------------------------------------------------------------
  // O LAÇO DORME QUANDO NINGUÉM ESTÁ VENDO
  //
  // Três situações em que desenhar é desperdício puro: aba oculta,
  // painel comercial aberto por cima da cena, e modo seguro. O legado já
  // tratava a aba; as outras duas não.
  //
  // Num celular isso é bateria, e bateria é o que decide se a segunda
  // demonstração do dia ainda roda.
  // ------------------------------------------------------------
  const painelComercial = document.getElementById('commercial');
  const reavaliarSono = () => {
    const escondido = document.hidden;
    const comercialAberto = !!painelComercial?.classList.contains('visible');
    const seguro = protecao.tier === 'PRESENTATION_SAFE';
    if (escondido || comercialAberto || seguro) cena.pauseRenderLoop();
    else cena.resumeRenderLoop();
  };
  document.addEventListener('visibilitychange', reavaliarSono);
  if (painelComercial) {
    new MutationObserver(reavaliarSono)
      .observe(painelComercial, { attributes: true, attributeFilter: ['class'] });
  }

  ligarBotoesDoHero(cena);
  ligarRelatorioDeDebug(protecao);
  ligarEscapeGlobal(fsm);
  fsm.aoMudar((estado) => anunciar(NOME_DO_ESTADO[estado] ?? estado));
  protecao.aoTrocarTier = ((anterior) => (tier, motivo) => {
    anterior?.(tier, motivo);
    if (tier === 'PRESENTATION_SAFE') {
      anunciar('Apresentação em modo compatível: navegação por imagens.');
    }
  })(protecao.aoTrocarTier);
  await ligarAudio(cena);
  registrarServiceWorker();
  marco('pronto');
}

/**
 * O botão de som vinha com `display:none` no HTML porque o áudio nunca
 * existiu — os MP3 do manifesto não estão no repositório. Agora o
 * ambiente é sintetizado em tempo de execução, então o botão aparece.
 *
 * O módulo de áudio só é BAIXADO quando o usuário clica: o Howler são
 * ~30 KB que ninguém precisa carregar para ver a casa em silêncio.
 */
async function ligarAudio(cena: {
  camera?: { position: { x: number; y: number; z: number }; getWorldDirection: (v: unknown) => void };
}): Promise<void> {
  const btn = document.getElementById('btn-audio');
  if (!btn) return;
  btn.style.display = '';
  btn.textContent = 'Som';

  let audioMod: typeof import('./core/AudioManager') | null = null;

  btn.addEventListener('click', async () => {
    if (!audioMod) {
      btn.textContent = '…';
      audioMod = await import('./core/AudioManager');
    }
    const ligado = audioMod.audio.alternar();
    btn.textContent = ligado ? 'Som ligado' : 'Som';
    btn.classList.toggle('active', ligado);
    analytics.registrar('audio', { ligado });

    if (!ligado) return;
    // O ouvinte só passa a ser atualizado quando há som para ouvir.
    const cam = cena.camera;
    if (!cam) return;
    const w = window as unknown as { __auraAntesDoQuadro?: ((dt: number) => void)[] };
    if ((w as { __auraOuvinte?: boolean }).__auraOuvinte) return;
    (w as { __auraOuvinte?: boolean }).__auraOuvinte = true;
    // Vector3 DE VERDADE, e não `{x,y,z}`: `getWorldDirection` chama
    // `target.set(...)` no que recebe. Com um objeto simples isso lança
    // TypeError dentro do gancho por quadro, o `WebGLAnimation` do three
    // nunca volta a pedir o quadro seguinte, e a cena CONGELA PARA
    // SEMPRE — na primeira vez que o cliente liga o som. Era o defeito
    // mais grave do projeto e estava escondido atrás de um botão.
    const { Vector3 } = await import('three');
    const frente = new Vector3(0, 0, -1);
    w.__auraAntesDoQuadro?.push(() => {
      // O gancho roda dentro do laço de render do legado, que não tem
      // try/catch: qualquer exceção aqui mata a animação inteira.
      try {
        cam.getWorldDirection(frente);
        audioMod?.audio.atualizarOuvinte(
          cam.position.x, cam.position.y, cam.position.z,
          frente.x, frente.y, frente.z,
        );
      } catch (e) {
        console.error('[audio] ouvinte falhou, seguindo sem espacializacao', e);
      }
    });
  });
}

/**
 * Os botoes do hero passam a falar com a FSM em vez de mexer no DOM
 * diretamente. E o que garante que "Explorar" e "Modo Cinematico" nunca
 * deixem a experiencia num estado hibrido.
 */
function ligarBotoesDoHero(cena: { Experience?: { set?: (s: string) => void } }): void {
  const hero = document.getElementById('hero');
  const esconderHero = () => {
    hero?.classList.add('hidden');
    hero?.classList.remove('visible');
  };

  document.getElementById('btn-explore')?.addEventListener('click', () => {
    analytics.registrar('modo', { modo: 'explorar' });
    fsm.ir('EXPLORING', esconderHero);
  });

  document.getElementById('btn-cinematic')?.addEventListener('click', () => {
    analytics.registrar('modo', { modo: 'cinematico' });
    fsm.ir('CINEMATIC', () => {
      esconderHero();
      cena.Experience?.set?.('cinematic');
    });
  });
}

principal().catch((e) => {
  console.error('Casa Aura: erro não tratado no boot', e);
});
